<style>
    h6 {
        margin: auto;
        padding: 5px;
        text-align: center;
        font-size: 0.9rem;
        color: white;
        background-color: black;
    }
</style>
<footer>
    <h6>Site feito para fins estudantis produzido por William Souza Almeida</h6>
</footer>